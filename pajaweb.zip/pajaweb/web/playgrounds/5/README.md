# Fruit Matcher
HTML5, CSS3 and Javascript memory game.

Play this game on http://mmenavas.github.io/memory-game
